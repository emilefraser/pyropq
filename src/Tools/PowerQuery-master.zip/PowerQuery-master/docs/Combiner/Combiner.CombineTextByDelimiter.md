# Combiner.CombineTextByDelimiter
Returns a function that combines a list of text into a single text using the specified delimiter.
> _function (<code>delimiter</code> as text, optional <code>quoteStyle</code> as nullable any) as function_

# Description 
Returns a function that combines a list of text into a single text using the specified delimiter.
# Category 
Combiner
