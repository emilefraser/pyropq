# Combiner.CombineTextByEachDelimiter
Returns a function that combines a list of text into a single text using each specified delimiter in sequence.
> _function (<code>delimiters</code> as list, optional <code>quoteStyle</code> as nullable any) as function_

# Description 
Returns a function that combines a list of text into a single text using each specified delimiter in sequence.
# Category 
Combiner
