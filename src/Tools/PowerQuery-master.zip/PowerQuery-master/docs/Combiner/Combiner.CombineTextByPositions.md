# Combiner.CombineTextByPositions
Returns a function that combines a list of text into a single text using the specified positions.
> _function (<code>positions</code> as list, optional <code>template</code> as nullable any) as function_

# Description 
Returns a function that combines a list of text into a single text using the specified positions.
# Category 
Combiner
