# Combiner.CombineTextByLengths
Returns a function that combines a list of text into a single text using the specified lengths.
> _function (<code>lengths</code> as list, optional <code>template</code> as nullable any) as function_

# Description 
Returns a function that combines a list of text into a single text using the specified lengths.
# Category 
Combiner
