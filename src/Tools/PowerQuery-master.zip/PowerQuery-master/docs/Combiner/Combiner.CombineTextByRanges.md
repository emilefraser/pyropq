# Combiner.CombineTextByRanges
Returns a function that combines a list of text into a single text using the specified positions and lengths.
> _function (<code>ranges</code> as list, optional <code>template</code> as nullable any) as function_

# Description 
Returns a function that combines a list of text into a single text using the specified positions and lengths.
# Category 
Combiner
