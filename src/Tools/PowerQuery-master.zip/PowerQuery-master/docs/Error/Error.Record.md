# Error.Record
Returns an error record from the provided text values for reason, message and detail.
> _function (<code>reason</code> as text, optional <code>message</code> as nullable any, optional <code>detail</code> as nullable any) as record_

# Description 
Returns an error record from the provided text values for reason, message and detail.
# Category 
Error
