# Binary.ToList
Converts a binary value into a list of numbers.
> _function (<code>binary</code> as binary) as list_

# Description 
Converts a binary value into a list of numbers.
# Category 
Binary
