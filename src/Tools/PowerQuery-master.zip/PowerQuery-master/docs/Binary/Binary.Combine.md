# Binary.Combine
Combines a list of binaries into a single binary.
> _function (<code>binaries</code> as list) as binary_

# Description 
Combines a list of binaries into a single binary.
# Category 
Binary
