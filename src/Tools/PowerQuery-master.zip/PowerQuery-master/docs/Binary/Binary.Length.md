# Binary.Length
Returns the number of characters.
> _function (optional <code>binary</code> as nullable any) as nullable any_

# Description 
Returns the number of characters.
# Category 
Binary
