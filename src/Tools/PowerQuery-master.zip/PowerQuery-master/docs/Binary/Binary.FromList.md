# Binary.FromList
Converts a list of numbers into a binary value.
> _function (<code>list</code> as list) as binary_

# Description 
Converts a list of numbers into a binary value.
# Category 
Binary
