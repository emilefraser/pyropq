# BinaryFormat.UnsignedInteger64
A binary format that reads a 64-bit unsigned integer.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads a 64-bit unsigned integer.
# Category 
Binary Formats.Reading numbers
