# BinaryFormat.7BitEncodedUnsignedInteger
A binary format that reads a 64-bit unsigned integer that was encoded using a 7-bit variable-length encoding.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads a 64-bit unsigned integer that was encoded using a 7-bit variable-length encoding.
# Category 
Binary Formats.Reading numbers
