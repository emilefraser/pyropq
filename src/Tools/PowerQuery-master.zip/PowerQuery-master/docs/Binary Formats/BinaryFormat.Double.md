# BinaryFormat.Double
A binary format that reads an 8-byte IEEE double-precision floating point value.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads an 8-byte IEEE double-precision floating point value.
# Category 
Binary Formats.Reading numbers
