# BinaryFormat.Null
A binary format that reads zero bytes and returns null.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads zero bytes and returns null.
# Category 
Binary Formats.Controlling what comes next
