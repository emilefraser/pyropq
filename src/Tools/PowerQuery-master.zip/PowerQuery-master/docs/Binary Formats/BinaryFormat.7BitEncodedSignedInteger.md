# BinaryFormat.7BitEncodedSignedInteger
A binary format that reads a 64-bit signed integer that was encoded using a 7-bit variable-length encoding.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads a 64-bit signed integer that was encoded using a 7-bit variable-length encoding.
# Category 
Binary Formats.Reading numbers
