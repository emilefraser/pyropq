# BinaryFormat.Decimal
A binary format that reads a .NET 16-byte decimal value.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads a .NET 16-byte decimal value.
# Category 
Binary Formats.Reading numbers
