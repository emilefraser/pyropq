# BinaryFormat.SignedInteger32
A binary format that reads a 32-bit signed integer.
> _function (<code>binary</code> as binary) as nullable any_

# Description 
A binary format that reads a 32-bit signed integer.
# Category 
Binary Formats.Reading numbers
