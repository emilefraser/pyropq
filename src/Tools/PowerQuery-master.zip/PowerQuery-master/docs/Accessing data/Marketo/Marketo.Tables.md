# Marketo.Tables
Enter the URL of the Marketo REST API endpoint associated with your account.
> _function (<code>url</code> as text, <code>QueryStart</code> as date) as table_

# Description 
Returns a table with relevant Marketo data.
# Category 
Accessing data
