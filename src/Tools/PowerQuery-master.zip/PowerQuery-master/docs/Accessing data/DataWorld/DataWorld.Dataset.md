# DataWorld.Dataset

> _function (<code>owner</code> as text, <code>id</code> as text, optional <code>query</code> as nullable any) as table_

# Description 
Retrieves a dataset from Data.World
# Category 
Accessing data
