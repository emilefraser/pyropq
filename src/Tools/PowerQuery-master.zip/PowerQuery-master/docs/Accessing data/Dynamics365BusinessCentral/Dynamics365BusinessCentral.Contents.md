# Dynamics365BusinessCentral.Contents
Enter your Microsoft Dynamics 365 Business Central company.
> _function (optional <code>company</code> as nullable any) as table_

# Description 
Returns a table with relevant Microsoft Dynamics 365 Business Central data.
# Category 
Accessing data
