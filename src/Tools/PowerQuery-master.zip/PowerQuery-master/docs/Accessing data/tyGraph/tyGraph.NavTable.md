# tyGraph.NavTable
uses https://api.tygraph.com/odata
> _function () as table_

# Description 

# Category 
Accessing data
