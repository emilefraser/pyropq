# Github.Tables
Enter the GitHub repository owner and the repository name.
> _function (<code>RepositoryOwner</code> as text, <code>Repository</code> as text) as table_

# Description 
Returns a table with relevant GitHub data.
# Category 
Accessing data
