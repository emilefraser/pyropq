# Dynamics365Financials.Contents
Enter your Dynamics 365 for Financials company.
> _function (optional <code>company</code> as nullable any) as table_

# Description 
Returns a table with relevant Dynamics 365 for Financials data.
# Category 
Accessing data
