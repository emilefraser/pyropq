# Xml.Tables
Returns the contents of the XML document as a nested collection of flattened tables.
> _function (optional <code>contents</code> as nullable any, optional <code>options</code> as nullable record, optional <code>encoding</code> as nullable any) as table_

# Description 
Returns the contents of the XML document as a nested collection of flattened tables.
# Category 
Accessing data
