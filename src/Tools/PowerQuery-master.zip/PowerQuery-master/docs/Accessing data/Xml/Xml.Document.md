# Xml.Document
Returns the contents of the XML document as a hierarchical table.
> _function (optional <code>contents</code> as nullable any, optional <code>encoding</code> as nullable any) as table_

# Description 
Returns the contents of the XML document as a hierarchical table.
# Category 
Accessing data
