# File.Contents
Returns the contents of the specified file as binary.
> _function (<code>path</code> as text) as binary_

# Description 
Returns the contents of the file, <code>path</code>, as binary.
# Category 
Accessing data
