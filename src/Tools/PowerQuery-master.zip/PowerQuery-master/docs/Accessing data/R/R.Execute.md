# R.Execute
Returns a table listing the tables resulting from running the R script.
> _function (<code>script</code> as text, optional <code>arguments</code> as nullable record) as table_

# Description 

# Category 
Accessing data
