# Facebook.Graph
Returns a record containing content from the Facebook graph.
> _function (<code>url</code> as text) as nullable any_

# Description 
Returns a record containing a set of tables found in the Facebook graph at the specified URL, <code>url</code>.
# Category 
Accessing data
