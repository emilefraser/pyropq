# MailChimp.TablesV2
Returns a table with key MailChimp data.
> _function () as table_

# Description 
Returns a table with key MailChimp data.
# Category 
Accessing data
# Examples 
Returns a table with key MailChimp data.
```
MailChimp.Tables()
```
> A table with key MailChimp data.

***
