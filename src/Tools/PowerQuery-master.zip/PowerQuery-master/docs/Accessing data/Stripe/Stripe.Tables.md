# Stripe.Tables
Returns a table listing the available Stripe tables and functions.
> _function () as table_

# Description 
Returns a table listing the available Stripe tables and functions.
# Category 
Accessing data
