# AmazonRedshift.Database
Import data from an Amazon Redshift database.
> _function (<code>server</code> as text, <code>database</code> as text, optional <code>options</code> as nullable record) as table_

# Description 
Returns a table listing the tables on the Amazon Redshift cluster <code>server</code> in the database <code>database</code>.
# Category 
Accessing data
