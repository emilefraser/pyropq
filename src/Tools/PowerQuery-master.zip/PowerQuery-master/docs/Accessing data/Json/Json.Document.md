# Json.Document
Returns the content of the JSON document.
> _function (optional <code>jsonText</code> as nullable any, optional <code>encoding</code> as nullable any) as nullable any_

# Description 
Returns the content of the JSON document.
# Category 
Accessing data
