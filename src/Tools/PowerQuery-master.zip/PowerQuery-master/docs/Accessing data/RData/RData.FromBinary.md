# RData.FromBinary
Returns a record of data frames from the RData file.
> _function (<code>stream</code> as binary) as nullable any_

# Description 
Returns a record of data frames from the RData file.
# Category 
Accessing data
