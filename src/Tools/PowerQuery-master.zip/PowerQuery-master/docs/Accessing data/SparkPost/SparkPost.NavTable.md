# SparkPost.NavTable
Enter the number of days of metrics to retrieve from SparkPost.
> _function (<code>DaysOffset</code> as number) as table_

# Description 

# Category 
Accessing data
