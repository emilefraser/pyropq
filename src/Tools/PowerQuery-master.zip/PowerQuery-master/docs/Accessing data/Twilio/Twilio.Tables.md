# Twilio.Tables
Enter the number of months of historical Twilio data to retrieve.
> _function (<code>historyMonths</code> as number) as table_

# Description 
Returns a table with relevant Twilio data.
# Category 
Accessing data
