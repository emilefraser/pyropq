# ActiveDirectory.Domains
Returns a list of Active Directory domains in the same forest as the specified domain or of the current machine's domain if none is specified.
> _function (optional <code>forestRootDomainName</code> as nullable any) as table_

# Description 
Returns a list of Active Directory domains in the same forest as the specified domain or of the current machine's domain if none is specified.
# Category 
Accessing data
