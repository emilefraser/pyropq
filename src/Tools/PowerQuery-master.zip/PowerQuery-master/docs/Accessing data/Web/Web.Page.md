# Web.Page
Returns the contents of the HTML document broken into its constituent structures, as well as a representation of the full document and its text after removing tags.
> _function (optional <code>html</code> as nullable any) as table_

# Description 
Returns the contents of the HTML document broken into its constituent structures, as well as a representation of the full document and its text after removing tags.
# Category 
Accessing data
