# Folder.Contents
Returns a table containing the properties and contents of the files and folders found in the specifed folder.
> _function (<code>path</code> as text) as table_

# Description 
Returns a table containing a row for each folder and file found at the folder path, <code>path</code>. Each row contains properties of the folder or file and a link to its content.
# Category 
Accessing data
