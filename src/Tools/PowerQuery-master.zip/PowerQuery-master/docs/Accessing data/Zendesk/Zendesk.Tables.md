# Zendesk.Tables
Enter the URL of your Zendesk account.
> _function (<code>url</code> as text) as table_

# Description 
Returns a table with relevant Zendesk data.
# Category 
Accessing data
