# MicrosoftAzureConsumptionInsights.Tables
Microsoft Azure Consumption Insights
> _function (<code>enrollmentNumber</code> as any, optional <code>parameters</code> as nullable record) as table_

# Description 
Microsoft Azure Consumption Insights
# Category 
Accessing data
