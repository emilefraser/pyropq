# DynamicsNav.Contents
Enter the URL of your Dynamics NAV OData service endpoint.
> _function (<code>url</code> as text, optional <code>company</code> as nullable any) as table_

# Description 
Returns a table with relevant Dynamics NAV data.
# Category 
Accessing data
