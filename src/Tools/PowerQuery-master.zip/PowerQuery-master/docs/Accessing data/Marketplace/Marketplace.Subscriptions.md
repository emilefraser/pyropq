# Marketplace.Subscriptions
Returns all the subscribed feeds from Azure Marketplace.
> _function () as table_

# Description 
Returns all the subscribed feeds from Azure Marketplace.
# Category 
Accessing data
