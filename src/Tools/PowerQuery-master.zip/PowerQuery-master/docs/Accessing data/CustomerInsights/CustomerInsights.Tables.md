# CustomerInsights.Tables
Enter the URL for your Customer Insights account
> _function (<code>url</code> as text) as table_

# Description 
Dynamics 365 for Customer Insights
# Category 
Accessing data
