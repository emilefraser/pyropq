# Impala.Database
Import data from an Impala cluster
> _function (<code>server</code> as text) as table_

# Description 
Import data from an Impala cluster <code>server</code>. If a port wasn't specified, the default port 21050 will be used.
# Category 
Accessing data
