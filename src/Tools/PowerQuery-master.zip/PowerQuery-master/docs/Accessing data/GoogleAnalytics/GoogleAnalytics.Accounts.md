# GoogleAnalytics.Accounts
Returns Google Analytics accounts.
> _function () as table_

# Description 
Returns Google Analytics accounts that are accessible from the current credential.
# Category 
Accessing data
