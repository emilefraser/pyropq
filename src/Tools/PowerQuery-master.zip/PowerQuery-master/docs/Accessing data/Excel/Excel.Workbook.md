# Excel.Workbook
Returns a record of Sheets from the Excel workbook.
> _function (<code>workbook</code> as binary, optional <code>useHeaders</code> as nullable any, optional <code>delayTypes</code> as nullable any) as table_

# Description 
Returns a record of Sheets from the Excel workbook.
# Category 
Accessing data
