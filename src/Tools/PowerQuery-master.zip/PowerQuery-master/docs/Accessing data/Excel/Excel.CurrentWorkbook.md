# Excel.CurrentWorkbook
Returns the tables in the current Excel Workbook.
> _function () as table_

# Description 
Returns the tables in the current Excel Workbook.
# Category 
Accessing data
