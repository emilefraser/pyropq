# AzureSpark.Tables
List the tables in an Azure Spark instance.
> _function (<code>server</code> as text) as table_

# Description 
List the tables in an Azure Spark instance.
# Category 
Accessing data
