# VSTS.AccountContents
Enter Url of your VSTS Analytics Service.
> _function (<code>url</code> as text, optional <code>options</code> as nullable record) as table_

# Description 
Returns the contents downloaded from the VSTS Analytics Service url as a binary value. This function uses different credentials for different accounts.
# Category 
Accessing data
