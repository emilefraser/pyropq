# VSTS.Contents
Enter Url of your VSTS Analytics Service.
> _function (<code>url</code> as text, optional <code>options</code> as nullable record) as table_

# Description 
Returns the contents downloaded from the VSTS Analytics Service url as a binary value. This function uses global credentials for all the accessible account.
# Category 
Accessing data
