# VSTS.Feed
Visual Studio Team Services Feed.
> _function (<code>url</code> as text, optional <code>options</code> as nullable record) as table_

# Description 
Returns a table of OData feeds offered by Visual Studio Team Services.
# Category 
Accessing data
