# VSTS.Views
Enter account and project names.
> _function (<code>url</code> as text, <code>project</code> as text, optional <code>areaPath</code> as nullable any, optional <code>options</code> as nullable record) as table_

# Description 
Returns a table of OData feeds offered by Visual Studio Team Services.
# Category 
Accessing data
