# Troux.CustomFeed
Enter the URL of your Planview Enterprise One - Capability and Technology Management account and a query.
> _function (<code>url</code> as text, <code>query</code> as text) as table_

# Description 
Returns a table with relevant Planview Enterprise One - Capability and Technology Management data specified by the query.
# Category 
Accessing data
