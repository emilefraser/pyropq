# Troux.Feed
Enter the URL of your Planview Enterprise One - Capability and Technology Management account.
> _function (<code>url</code> as text) as table_

# Description 
Returns a table with relevant Planview Enterprise One - Capability and Technology Management data.
# Category 
Accessing data
