# comScore.NavTable

> _function (<code>datacenter</code> as text, <code>client</code> as text, optional <code>startDate</code> as nullable any, optional <code>endDate</code> as nullable any) as table_

# Description 

# Category 
Accessing data
# Examples 

```

```
> 

***
