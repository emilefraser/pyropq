# Projectplace.Feed
Enter the URL of your Planview Projectplace account.
> _function (<code>ODataURL</code> as text) as table_

# Description 
Returns a table with relevant Planview Projectplace data.
# Category 
Accessing data
