# Webtrends.Tables
Enter the Profile ID associated with your Webtrends account.
> _function (<code>ProfileId</code> as text, optional <code>startDate</code> as nullable any, optional <code>endDate</code> as nullable any) as table_

# Description 
Returns a table with relevant Webtrends data.
# Category 
Accessing data
