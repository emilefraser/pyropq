# Diagnostics.ActivityId
Returns an opaque identifier for the currently-running evaluation.
> _function () as nullable any_

# Description 
Returns an opaque identifier for the currently-running evaluation.
# Category 
Diagnostics
