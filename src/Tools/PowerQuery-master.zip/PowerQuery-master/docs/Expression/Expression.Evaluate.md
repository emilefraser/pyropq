# Expression.Evaluate
Expression.Evaluate
> _function (<code>document</code> as text, optional <code>environment</code> as nullable record) as nullable any_

# Description 
Expression.Evaluate
# Category 
Expression
