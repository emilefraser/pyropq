# Expression.Identifier
Expression.Identifier
> _function (<code>name</code> as text) as text_

# Description 
Expression.Identifier
# Category 
Expression
