# Expression.Constant
Expression.Constant
> _function (optional <code>value</code> as nullable any) as text_

# Description 
Expression.Constant
# Category 
Expression
