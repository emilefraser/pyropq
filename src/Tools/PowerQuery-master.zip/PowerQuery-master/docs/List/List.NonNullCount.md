# List.NonNullCount
Returns the number of non-null items in the list.
> _function (<code>list</code> as list) as number_

# Description 
Returns the number of non-null items in the list <code>list</code>.
# Category 
List.Information
