# Number.Factorial
Returns the factorial of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the factorial of the number <code>number</code>.
# Category 
Number.Operations
# Examples 
Find the factorial of 10.
```
Number.Factorial(10)
```
> 3628800

***
