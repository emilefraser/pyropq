# Number.BitwiseOr
Returns the result of performing a bitwise "Or" between the two inputs.
> _function (optional <code>number1</code> as nullable any, optional <code>number2</code> as nullable any) as nullable any_

# Description 
Returns the result of performing a bitwise "Or" between <code>number1</code> and <code>number2</code>.
# Category 
Number.Bytes
