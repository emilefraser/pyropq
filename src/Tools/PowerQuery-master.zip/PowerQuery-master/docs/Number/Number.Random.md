# Number.Random
Returns a random number.
> _function () as number_

# Description 
Returns a random number between 0 and 1.
# Category 
Number.Random
# Examples 
Get a random number.
```
Number.Random()
```
> 0.919303

***
