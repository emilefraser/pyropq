# Number.Atan
Returns the arctangent of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the arctangent of <code>number</code>.
# Category 
Number.Trigonometry
