# Number.Tanh
Returns the hyperbolic tangent of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the hyperbolic tangent of <code>number</code>.
# Category 
Number.Trigonometry
