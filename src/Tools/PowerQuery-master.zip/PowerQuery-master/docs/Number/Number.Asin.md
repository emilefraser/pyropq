# Number.Asin
Returns the arcsine of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the arcsine of <code>number</code>.
# Category 
Number.Trigonometry
