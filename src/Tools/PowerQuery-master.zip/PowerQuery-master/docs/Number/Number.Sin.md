# Number.Sin
Returns the sine of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the sine of <code>number</code>.
# Category 
Number.Trigonometry
# Examples 
Find the sine of the angle 0.
```
Number.Sin(0)
```
> 0

***
