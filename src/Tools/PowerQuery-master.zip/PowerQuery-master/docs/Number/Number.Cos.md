# Number.Cos
Returns the cosine of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the cosine of <code>number</code>.
# Category 
Number.Trigonometry
# Examples 
Find the cosine of the angle 0.
```
Number.Cos(0)
```
> 1

***
