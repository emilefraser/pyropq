# Number.Tan
Returns the tangent of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the tangent of <code>number</code>.
# Category 
Number.Trigonometry
# Examples 
Find the tangent of the angle 1.
```
Number.Tan(1)
```
> 1.5574077246549023 

***
