# Number.Sinh
Returns the hyperbolic sine of the number.
> _function (optional <code>number</code> as nullable any) as nullable any_

# Description 
Returns the hyperbolic sine of <code>number</code>.
# Category 
Number.Trigonometry
