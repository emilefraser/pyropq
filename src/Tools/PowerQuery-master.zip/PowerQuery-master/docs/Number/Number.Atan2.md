# Number.Atan2
Returns the arctangent of the division of the two numbers.
> _function (optional <code>y</code> as nullable any, optional <code>x</code> as nullable any) as nullable any_

# Description 
Returns the arctangent of the division of the two numbers, <code>y</code> and <code>x</code>. The divison will be constructed as <code>y</code>/<code>x</code>.
# Category 
Number.Trigonometry
