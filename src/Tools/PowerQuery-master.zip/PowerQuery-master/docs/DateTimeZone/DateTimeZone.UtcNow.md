# DateTimeZone.UtcNow
Returns the current date and time in UTC (the GMT timezone).
> _function () as datetimezone_

# Description 
Returns the current date and time in UTC (the GMT timezone).
# Category 
DateTimeZone
# Examples 
Get the current date & time in UTC.
```
DateTimeZone.UtcNow()
```
> #datetimezone(2011, 8, 16, 23, 34, 37.745, 0, 0)

***
