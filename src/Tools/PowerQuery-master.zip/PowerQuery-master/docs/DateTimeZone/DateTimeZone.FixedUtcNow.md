# DateTimeZone.FixedUtcNow
Returns the current date and time in UTC (the GMT timezone). This value is fixed and will not change with successive calls.
> _function () as datetimezone_

# Description 
Returns the current date and time in UTC (the GMT timezone). This value is fixed and will not change with successive calls.
# Category 
DateTimeZone
