# DateTimeZone.ZoneMinutes
Changes the timezone of the value.
> _function (optional <code>dateTimeZone</code> as nullable any) as nullable any_

# Description 
Changes the timezone of the value.
# Category 
DateTimeZone
