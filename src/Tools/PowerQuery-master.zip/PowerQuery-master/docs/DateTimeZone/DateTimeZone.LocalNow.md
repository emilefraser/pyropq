# DateTimeZone.LocalNow
Returns the current date & time in the local timezone.
> _function () as datetimezone_

# Description 
Returns a <code>datetimezone</code> value set to the current date and time on the system. 
    The returned value contains timezone information representing the local timezone.
# Category 
DateTimeZone
