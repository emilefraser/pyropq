# Lines.ToBinary
Converts a list of text into a binary value using the specified encoding and lineSeparator.The specified lineSeparator is appended to each line.  If not specified then the carriage return and line feed characters are used.
> _function (<code>lines</code> as list, optional <code>lineSeparator</code> as nullable any, optional <code>encoding</code> as nullable any, optional <code>includeByteOrderMark</code> as nullable any) as binary_

# Description 
Converts a list of text into a binary value using the specified encoding and lineSeparator.The specified lineSeparator is appended to each line.  If not specified then the carriage return and line feed characters are used.
# Category 
Lines
