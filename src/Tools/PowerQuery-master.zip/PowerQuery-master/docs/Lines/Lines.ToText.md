# Lines.ToText
Converts a list of text into a single text.  The specified lineSeparator is appended to each line.  If not specified then the carriage return and line feed characters are used.
> _function (<code>lines</code> as list, optional <code>lineSeparator</code> as nullable any) as text_

# Description 
Converts a list of text into a single text.  The specified lineSeparator is appended to each line.  If not specified then the carriage return and line feed characters are used.
# Category 
Lines
