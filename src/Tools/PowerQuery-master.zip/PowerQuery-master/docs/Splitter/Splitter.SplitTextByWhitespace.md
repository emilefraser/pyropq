# Splitter.SplitTextByWhitespace
Returns a function that splits text into a list of text at whitespace.
> _function (optional <code>quoteStyle</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text at whitespace.
# Category 
Splitter
