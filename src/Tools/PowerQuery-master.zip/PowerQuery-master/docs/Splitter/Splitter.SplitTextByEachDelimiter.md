# Splitter.SplitTextByEachDelimiter
Returns a function that splits text into a list of text at each specified delimiter in sequence.
> _function (<code>delimiters</code> as list, optional <code>quoteStyle</code> as nullable any, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text at each specified delimiter in sequence.
# Category 
Splitter
