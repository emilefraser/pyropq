# Splitter.SplitTextByRepeatedLengths
Returns a function that splits text into a list of text after the specified length repeatedly.
> _function (<code>length</code> as number, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text after the specified length repeatedly.
# Category 
Splitter
