# Splitter.SplitTextByRanges
Returns a function that splits text into a list of text according to the specified offsets and lengths.
> _function (<code>ranges</code> as list, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text according to the specified offsets and lengths.
# Category 
Splitter
