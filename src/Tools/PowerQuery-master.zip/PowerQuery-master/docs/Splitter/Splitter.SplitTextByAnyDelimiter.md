# Splitter.SplitTextByAnyDelimiter
Returns a function that splits text into a list of text at any of the specified delimiters.
> _function (<code>delimiters</code> as list, optional <code>quoteStyle</code> as nullable any, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text at any of the specified delimiters.
# Category 
Splitter
