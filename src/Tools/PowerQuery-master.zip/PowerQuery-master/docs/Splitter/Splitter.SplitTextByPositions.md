# Splitter.SplitTextByPositions
Returns a function that splits text into a list of text at each specified position.
> _function (<code>positions</code> as list, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text at each specified position.
# Category 
Splitter
