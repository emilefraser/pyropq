# Splitter.SplitTextByDelimiter
Returns a function that splits text into a list of text according to the specified delimiter.
> _function (<code>delimiter</code> as text, optional <code>quoteStyle</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text according to the specified delimiter.
# Category 
Splitter
