# Splitter.SplitByNothing
Returns a function that does no splitting, returning its argument as a single element list.
> _function () as function_

# Description 
Returns a function that does no splitting, returning its argument as a single element list.
# Category 
Splitter
