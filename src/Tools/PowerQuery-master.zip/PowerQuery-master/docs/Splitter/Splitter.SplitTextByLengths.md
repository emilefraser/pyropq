# Splitter.SplitTextByLengths
Returns a function that splits text into a list of text by each specified length.
> _function (<code>lengths</code> as list, optional <code>startAtEnd</code> as nullable any) as function_

# Description 
Returns a function that splits text into a list of text by each specified length.
# Category 
Splitter
