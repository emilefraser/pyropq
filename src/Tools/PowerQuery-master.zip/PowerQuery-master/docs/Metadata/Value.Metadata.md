# Value.Metadata
Returns a record containing the input's metadata.
> _function (optional <code>value</code> as nullable any) as nullable any_

# Description 
Returns a record containing the input's metadata.
# Category 
Metadata
