# Value.ReplaceMetadata
Replaces the input's metadata information.
> _function (optional <code>value</code> as nullable any, optional <code>metaValue</code> as nullable any) as nullable any_

# Description 
Replaces the input's metadata information.
# Category 
Metadata
