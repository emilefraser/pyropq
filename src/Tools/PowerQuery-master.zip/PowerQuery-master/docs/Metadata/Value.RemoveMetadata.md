# Value.RemoveMetadata
Strips the input of metadata.
> _function (optional <code>value</code> as nullable any, optional <code>metaValue</code> as nullable any) as nullable any_

# Description 
Strips the input of metadata.
# Category 
Metadata
