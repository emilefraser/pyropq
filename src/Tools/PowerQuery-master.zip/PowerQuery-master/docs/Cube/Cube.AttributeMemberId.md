# Cube.AttributeMemberId
Returns the unique member identifier from members property value.
> _function (optional <code>attribute</code> as nullable any) as nullable any_

# Description 
Returns the unique member identifier from a member property value. <code>attribute</code>. Returns null for any other values.
# Category 
Cube
