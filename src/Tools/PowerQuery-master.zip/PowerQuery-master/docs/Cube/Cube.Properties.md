# Cube.Properties
Returns a table containing the set of available properties for dimensions that are expanded in the cube.
> _function (<code>cube</code> as table) as table_

# Description 
Returns a table containing the set of available properties for dimensions that are expanded in the cube.
# Category 
Cube
