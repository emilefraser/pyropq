# Cube.PropertyKey
Returns the key of a property.
> _function (optional <code>property</code> as nullable any) as nullable any_

# Description 
Returns the key of property <code>property</code>.
# Category 
Cube
