# Cube.DisplayFolders
Returns a nested tree of tables representing the display folder hierarchy of the objects (e.g. dimensions and measures).
> _function (<code>cube</code> as table) as table_

# Description 
Returns a nested tree of tables representing the display folder hierarchy of the objects (e.g. dimensions and measures) available for use in the <code>cube</code>.
# Category 
Cube
