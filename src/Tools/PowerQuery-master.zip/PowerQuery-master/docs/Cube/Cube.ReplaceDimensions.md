# Cube.ReplaceDimensions
Cube.ReplaceDimensions
> _function (<code>cube</code> as table, <code>dimensions</code> as table) as table_

# Description 
Cube.ReplaceDimensions
# Category 
Cube
