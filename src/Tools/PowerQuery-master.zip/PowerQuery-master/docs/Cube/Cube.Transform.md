# Cube.Transform
Applies a list of cube functions.
> _function (<code>cube</code> as table, <code>transforms</code> as list) as table_

# Description 
Applies the list cube functions, <code>transforms</code>, on the <code>cube</code>.
# Category 
Cube
