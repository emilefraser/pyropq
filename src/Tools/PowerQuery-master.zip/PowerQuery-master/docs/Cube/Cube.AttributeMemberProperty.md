# Cube.AttributeMemberProperty
Returns a property of a dimension attribute.
> _function (optional <code>attribute</code> as nullable any, <code>propertyName</code> as text) as nullable any_

# Description 
Returns the property <code>propertyName</code> of dimension attribute <code>attribute</code>.
# Category 
Cube
