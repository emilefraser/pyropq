# DateTime.LocalNow
Returns the current date and time in the local timezone.
> _function () as datetime_

# Description 
Returns a <code>datetime</code> value set to the current date and time on the system.
# Category 
DateTime
