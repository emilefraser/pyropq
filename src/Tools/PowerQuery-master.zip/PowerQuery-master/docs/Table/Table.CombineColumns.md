# Table.CombineColumns
Combines the specified columns into a new column using the specified combiner function.
> _function (<code>table</code> as table, <code>sourceColumns</code> as list, <code>combiner</code> as function, <code>column</code> as text) as table_

# Description 
Combines the specified columns into a new column using the specified combiner function.
# Category 
Table.Transformation
