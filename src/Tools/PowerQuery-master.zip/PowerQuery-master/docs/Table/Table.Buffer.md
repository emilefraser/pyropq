# Table.Buffer
Buffers a table in memory, isolating it from external changes during evaluation.
> _function (<code>table</code> as table) as table_

# Description 
Buffers a table in memory, isolating it from external changes during evaluation.
# Category 
Table.Other
