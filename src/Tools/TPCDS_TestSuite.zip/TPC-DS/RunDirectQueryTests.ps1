﻿param (
    [Parameter(Mandatory=$True)]
    [string]$filePath,
    [Parameter(Mandatory=$True)]
    [string]$traceDirectory,
    [Parameter(Mandatory=$True)]
    [string]$connector
)

$server = "localhost:2384"
$traceLevel = "High" # High, Medium, Low, Duration, DurationResult


$dateStamp = Get-Date -Format "yyyyMMdd_HHmm"
$traceFileName = "$connector.$dateStamp"

# TODO - validate that Power BI Desktop is up and running

$lastDirectory = ""
$runningTotal = 0

$files = Get-ChildItem -Recurse $filePath -Filter *.mdx
foreach ($f in $files)
{
    $dir = Split-Path -Leaf $f.Directory
    if ($lastDirectory -ne $dir)
    {
        if ($runningTotal -ne 0)
        {
            Write-Host "[" $runningTotal.TotalSeconds "seconds ]"
        }

        Write-Host "[" $dir "]"
        $lastDirectory = $dir
        $runningTotal = 0
    }

    if ($f.Name -like '*DONOTRUN*')
    {
        Write-Host "Skipping file" $f.Name
    }
    else
    {
        $tf = $traceFileName + "." + $f.Name + ".csv"
        $traceFile = Join-Path $traceDirectory $tf

        $t = Measure-Command { Invoke-ASCmd -InputFile $f.FullName -Server $server -TraceFile $traceFile -TraceLevel $traceLevel }
        Write-Host "Ran query" $f.Name "in" $t.TotalMilliseconds "ms"
        
        $runningTotal = $runningTotal + $t
    }
}

if ($runningTotal -ne 0)
{
    Write-Host "[" $runningTotal.TotalSeconds "seconds ]"
}

